package handball;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TeamTests {

    private static final String NAME = "Test";
    private static final int POSITION = 3;


    @Test(expected = NullPointerException.class)
    public void test_setName_ThrowsNullPointerException_whenNameIsNULLorEmpty () {
        Team team1 = new Team(null,POSITION);
    }

    @Test
    public void test_setName_AddsNameCorrectly () {
        Team team = new Team(NAME, POSITION);

        Assert.assertEquals(NAME,team.getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_setPosition_ThrowsIllegalArgumentException_WhenPositionLessThanZero() {
        Team team = new Team(NAME, -1);
    }

    @Test
    public void test_setPosition_AddsPositionCorrectly () {
        Team team = new Team(NAME, POSITION);

        Assert.assertEquals(POSITION,team.getPosition());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_Add_ThrowsIllegalArgumentException_WhenSizeEqualsPosition() {
        Team team = new Team(NAME, 0);
        team.add(new HandballPlayer("Pesho"));
    }

    @Test
    public void test_Add_IncreasesTheSizeOfHandballPlayers() {
        Team team = new Team(NAME, POSITION);
        int count = team.getCount();
        team.add(new HandballPlayer("Pesho"));

        Assert.assertEquals(count + 1, team.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_Remove_ThrowsIllegalArgumentException_WhenNoPlayerIsFound() {
        Team team = new Team(NAME, POSITION);
        team.remove("Pesho");
    }
    @Test
    public void test_Remove_DecreasesTheSizeOfHandballPlayers() {
        Team team = new Team(NAME, POSITION);

        team.add(new HandballPlayer("Pesho"));

        int count = team.getCount();

        team.remove("Pesho");

        Assert.assertEquals(count - 1, team.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_playerForAnotherTeam_ThrowsIllegalArgumentException_WhenHandballPlayerIsNULL() {
        Team team = new Team(NAME, POSITION);
        team.playerForAnotherTeam("Pesho");
    }

    @Test
    public void test_playerForAnotherTeamReturnsCorrectPlayer() {
        Team team = new Team(NAME, POSITION);
        HandballPlayer test = new HandballPlayer("Pesho");
        team.add(test);

        HandballPlayer pesho = team.playerForAnotherTeam("Pesho");

        Assert.assertEquals(test, pesho);
        Assert.assertFalse(pesho.isActive());
    }
}
