package handball.entities.team;
//I can only play Outdoor!
public class Bulgaria extends BaseTeam{
    public Bulgaria(String name, String country, int advantage) {
        super(name, country, advantage);
    }
}
