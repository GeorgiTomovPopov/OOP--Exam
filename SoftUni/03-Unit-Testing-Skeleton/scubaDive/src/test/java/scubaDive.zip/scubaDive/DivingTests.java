package scubaDive;


import org.junit.Assert;
import org.junit.Test;

public class DivingTests {

    private static final String NAME = "Test";
    private static final int CAPACITY = 10;

    @Test(expected = NullPointerException.class)
    public void test_setName_ThrowsExceptionWhenNameIsNull() {
        Diving diving = new Diving(null,CAPACITY);
    }

    @Test(expected = NullPointerException.class)
    public void test_setName_ThrowsExceptionWhenNameIsEmpty() {
        Diving diving = new Diving("",CAPACITY);
    }

    @Test
    public void test_setName_SetsCorrectName() {
        Diving diving = new Diving(NAME,CAPACITY);

        Assert.assertEquals(NAME, diving.getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_setCapacity_ThrowsIllegalArgumentExceptionWhenCapacityLessThanZero() {
        Diving diving = new Diving(NAME,-1);
    }

    @Test
    public void test_setCapacity_SetsCorrectValueForCapacity() {
        Diving diving = new Diving(NAME,CAPACITY);
        Assert.assertEquals(CAPACITY, diving.getCapacity());
    }


    @Test(expected = IllegalArgumentException.class)
    public void addDeepWaterDiver_ThrowsIllegalArgumentExceptionWhenCapacityReached() {
        Diving diving = new Diving(NAME,0);
        diving.addDeepWaterDiver(new DeepWaterDiver("Pesho", 15));
    }

    @Test(expected = IllegalArgumentException.class)
    public void addDeepWaterDiver_ThrowsIllegalArgumentExceptionWhenDriverExists() {
        Diving diving = new Diving(NAME,CAPACITY);

        diving.addDeepWaterDiver(new DeepWaterDiver("Pesho", 15));
        diving.addDeepWaterDiver(new DeepWaterDiver("Pesho", 15));

    }

    @Test
    public void addDeepWaterDiver_SuccessfullyAddsDiver() {
        Diving diving = new Diving(NAME,CAPACITY);
        int initial = diving.getCount();

        diving.addDeepWaterDiver(new DeepWaterDiver("Pesho", 15));

        int newCound = diving.getCount();

        Assert.assertEquals(initial + 1, newCound);


    }

    @Test
    public void removeDeepWaterDiver_RemovesDiver() {
        Diving diving = new Diving(NAME,CAPACITY);
        int initial = diving.getCount();

        diving.addDeepWaterDiver(new DeepWaterDiver("Pesho", 15));
        int count = diving.getCount();

        diving.removeDeepWaterDiver("Pesho");
        int countAfterRemoval = diving.getCount();

        Assert.assertEquals(count - 1, countAfterRemoval);
    }


}
