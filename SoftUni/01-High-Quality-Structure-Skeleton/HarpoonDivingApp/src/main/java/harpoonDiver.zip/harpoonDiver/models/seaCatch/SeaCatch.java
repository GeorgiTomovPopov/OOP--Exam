package harpoonDiver.models.seaCatch;

import java.util.Collection;

public interface SeaCatch {
    Collection<String> getSeaCreatures();
}
